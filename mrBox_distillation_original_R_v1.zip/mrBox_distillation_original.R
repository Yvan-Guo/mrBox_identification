suppressPackageStartupMessages({
  library(Hmisc)
  library(ggplot2)
  library(ggpubr)
  library(reticulate)
  library(writexl)
  library(stringr)
  library(Biostrings)
  library(parallel)
  library(dplyr)
  library(readr)
  library(fdrtool)
  library(data.table)
})

setwd('main_pathway')

# Load and preprocess annotations
CpG_id <- fread("data/illuminaMethyl450_hg38_GDC.txt", 
                header = FALSE, 
                data.table = FALSE, 
                skip = "#", col.names = c("Gene", "Chrosome", "Site"))
CpG_id <- CpG_id[CpG_id$Chrosome != '*',]

# Load and preprocess DNA sequences
Seqset <- readDNAStringSet('data/CpG_sequence_set.txt')
anno <- unique(data.frame(names = Seqset@ranges@NAMES))
rownames(anno) <- anno$names

# Load and preprocess methylation data
met_ds <- fread("data/PANCAN_HumanMethylation450.tsv.gz", data.table = FALSE)
rownames(met_ds) <- met_ds[,1]
met_ds <- met_ds[,-1]

# Merge annotations with methylation data
met_ds <- merge(met_ds, anno, by = 'row.names')
rownames(met_ds) <- met_ds[, 1]
met_ds <- met_ds[, -c(1, ncol(met_ds))]

num_chr <- table(CpG_id$Chrosome)

Cor_frame <- function(r, grid_size = 1250, cor_type = 'spearman') {
  a0 <- (r-1) * grid_size + 1
  a <- seq(a0, min(a0 + grid_size - 1, nrow(met_ds)))
  cor <- matrix(NA, nrow = nrow(met_ds), ncol = length(a))
  P_cor <- cor
  
  for (k in seq_len(loop)) {
    b <- seq((k-1) * grid_size + 1, min(k * grid_size, nrow(met_ds)))
    if (length(a) == length(b)) {
      test <- cbind(t(met_ds[a, ]), t(met_ds[b, ]))
      x <- rcorr(as.matrix(test), type = cor_type)
      cor[b, seq_along(a)] <- round(x$r[(length(a) + 1):ncol(test), 1:length(a)], 2)
      raw_p_values <- x$P[(length(a) + 1):ncol(test), 1:length(a)]
      
      # Perform Benjamini-Hochberg adjustment
      adjusted_p_values <- p.adjust(as.vector(raw_p_values), method = "BH")
      adjusted_p_values <- matrix(adjusted_p_values, nrow = length(b), byrow = TRUE)
      
      P_cor[b, seq_along(a)] <- ifelse(adjusted_p_values > 0.05, 0, 1) # Adjusted p-value
    }
  }
  
  cor <- cor[seq_len(nrow(met_ds)), , drop = FALSE] * P_cor[seq_len(nrow(met_ds)), , drop = FALSE]
  write.csv(cor, paste0(pth1, '/', as.character(r), '.csv'))
}

Predict_mrDNA <- function(col_n) {
  source_python("code/Slice.py")
  source_python("code/extract_simple.py")
  source_python("code/finalseq.py")
  
  loc <- colnames(sq_r)[col_n]
  pth <- paste0("temp/",loc)
  dir.create(pth)
  
  cor <- data.frame(Site = sq_r[, 1], Rvalue = sq_r[, col_n])
  cor <- cor[order(cor$Rvalue, decreasing = TRUE),]
  cor <- na.omit(cor)
  
  top_sites <- cor$Site[2:101]
  bottom_sites <- cor$Site[(nrow(cor) - 99):nrow(cor)]
  
  S_tar <- Seqset[loc]
  S_Pos <- Seqset[top_sites]
  S_Neg <- Seqset[bottom_sites]
  
  writeXStringSet(S_tar, paste0(pth, '/Target.txt'))
  writeXStringSet(S_Pos, paste0(pth, '/Pos.txt'))
  writeXStringSet(S_Neg, paste0(pth, '/Neg.txt'))
  
  slice_py(loc)
  
  makeblastdb <- "NCBI/blast-BLAST_VERSION+/bin/makeblastdb.exe"
  blastn <- "NCBI/blast-BLAST_VERSION+/bin/blastn.exe"
  
  system2(makeblastdb, args = c("-in", paste0(pth, "/Pos.txt"), "-dbtype", "nucl", "-out", paste0(pth, "/Pos")))
  system2(makeblastdb, args = c("-in", paste0(pth, "/Neg.txt"), "-dbtype", "nucl", "-out", paste0(pth, "/Neg")))
  
  system2(blastn, args = c("-db", paste0(pth, "/Pos"), "-query", paste0(pth, "/Slice_1_8000.txt"), "-out", paste0(pth, "/Slice_P.txt"), "-outfmt", "7", "-num_threads", 2))
  
  output <- tryCatch({
    read.delim(paste0(pth, '/Slice_P.txt'), header = FALSE, comment.char = "#")
  }, error = function(e) NULL)
  
  if (!is.null(output)) {
    P_Slice <- output[, c(1, 12), with = FALSE] %>%
      group_by(V1) %>%
      filter(n() > 10) %>%
      ungroup() %>%
      mutate(Dataset = "Pos.")
    
    if (nrow(P_Slice) > 0) {
      wil_P <- P_Slice %>%
        group_by(Loc_l = V1) %>%
        summarise(P = wilcox.test(Score ~ Dataset, data = .)$p.value) %>%
        mutate(Signif = ifelse(is.na(P), 0, P)) %>%
        filter(Signif <= 0.05)
      
      if (nrow(wil_P) > 0) {
        write_xlsx(wil_P, paste0(pth, '/extracted_temp.xlsx'))
        
        if (extract_py(loc) != 1) {
          execute_blast_analysis(loc, pth)
        }
      }
    }
  }
  
  unlink(pth, recursive = TRUE)
}

blast_analysis <- function(input, db, output_file) {
  system2("C:/Program Files/NCBI/blast-BLAST_VERSION+/bin/blastn.exe", 
          args = c("-db", db, "-query", input, "-out", 
                   paste0(dirname(input), '/', output_file), 
                   "-outfmt", "7", "-num_threads", 2))
}

execute_blast_analysis <- function(loc, pth) {
  input <- paste0(pth, '/result.txt')
  output_PosB <- blast_analysis(input, paste0(pth, '/Pos'), 'PosB_result.txt')
  PosB <- read.delim(output_PosB, header = FALSE, comment.char = "#")
  PosB <- PosB %>% mutate(merged_col = paste(V1, V2, sep = ""), V_mean = aggregate(V1, by = list(V12), FUN = mean)$x)
  tpos <- table(PosB$V_mean)
  
  output_NegB <- blast_analysis(input, paste0(pth, '/Neg'), 'NegB_result.txt')
  NegB <- read_delim(output_NegB)
  
  tneg <- ifelse(is.null(NegB), data.frame(Pos = rep(0, length(tpos))), aggregate(NegB$V1, by = list(NegB$V_mean), FUN = mean))
  
  t_blast <- merge(data.frame(Row = as.numeric(names(tpos)), Pos = as.numeric(tpos)), data.frame(Row = as.numeric(names(tneg)), Neg = as.numeric(tneg)), by = 'Row', all.x = TRUE)
  t_blast$Neg[is.na(t_blast$Neg)] <- 0
  t_blast <- t_blast %>%
    filter(Pos > 25) %>%
    rowwise() %>%
    mutate(st = floor(Row / 1e7), en = Row %% 1e7) %>%
    filter(fisher.test(matrix(c(Pos, Neg, 100 - Pos, 100 - Neg), ncol = 2))$p.value <= 0.05) %>%
    select(st, en)
  
  if (nrow(t_blast) > 0) {
    write_xlsx(t_blast, paste0(pth, '/t_blast_temp.xlsx'))
    finalseq_chr_py(loc,pth1)}
}

main <- function(num_chr, CpG_id, met_ds, grid_size = 1250) {
  for (i in seq_len(24)) {
    n_i <- names(num_chr)[i]
    temp_anno <- CpG_id[CpG_id$Chrosome == n_i,]
    met <- met_ds[rownames(temp_anno),]
    
    pth1 <- paste0('cor_data_row/cor_frame_', n_i)
    dir.create(pth1)
    
    l_met <- nrow(met)
    loop <- ceiling(l_met / grid_size)
    
    if (length(list.files(pth1, pattern = '\\.csv$')) < loop) {
      print('building...')
      cl <- makeCluster(25)
      clusterExport(cl, c('met', 'pth1', 'l_met', 'loop', 'Cor_frame'))
      clusterEvalQ(cl, library(Hmisc))
      try(clusterApplyLB(cl, seq_len(loop), Cor_frame), silent = TRUE)
      stopCluster(cl)
    }
    
    if (length(list.files(pth1, pattern = '\\.csv$')) < loop) {
      print('Cannot build correlation database, please try less cores!')
    }
    
    for (n_cor in seq_len(loop)) {
      print('Enrichment analysis......')
      sq_r <- fread(paste0(pth1, '/', n_cor, '.csv'), data.table = FALSE)
      seq(2, ncol(sq_r)) %>%
        {cl <- makeCluster(45)
        clusterExport(cl, c('Seqset', 'sq_r', 'pth1', 'loop', 'Predict_mrDNA'))
        clusterEvalQ(cl, libraries = c(library(reticulate), library(writexl), library(Biostrings)))
        try(clusterApplyLB(cl, ., Predict_mrDNA), silent = TRUE)
        stopCluster(cl)}
    }
  }
}

main(num_chr, CpG_id, met_ds)
