# -*- coding: utf-8 -*-
"""
Created on Mon Mar 15 23:23:39 2021

@author: Yvan Guo
"""

from openpyxl import load_workbook

def extract_py_sum(loc):
    from openpyxl import load_workbook
    seq=''
    with open('temp/'+str(loc)+'/Target.txt','r') as f:
        tar=f.readline()[:-1]
        for line in f.readlines():
            seq = seq+line.strip('\n')
    f.close()
    
    wb=load_workbook('temp/'+str(loc)+'/extracted_temp.xlsx')
    ws=wb[wb.sheetnames[0]]
    rm=ws.max_row
    
    st=[]
    en=[]
    for r in range(2,rm+1):
        lo=ws.cell(r,1).value
        st.append(lo-100)
        en.append(lo+300)
    if(en==[] or st==[]):
        return 1
    else:
        i=1
        mx=max(en)
        while(1):
            if(en[i-1]==mx):
                break
            if(st[i]<=en[i-1]):
                del st[i]
                del en[i-1]
                continue
            i=i+1
        if(en[i-1]>8000):
            en[i-1]=8000
        if(st[0]<1):
            st[0]=1
        
        f=open('temp/'+str(loc)+'/result.txt','w')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write('>'+str(fr*10000000+to)+'\n')
            f.write(sequence+'\n')
        f.close()
        
        f=open('temp/'+str(loc)+'/G_sequence_cluster.txt','a')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write(tar+'_'+str(fr*10000000+to)+'\n')
            f.write(sequence+'\n')
            f.write('\n')
        f.close()
        return 0

def extract_py(loc):
    seq=''
    with open('temp/'+str(loc)+'/Target.txt','r') as f:
        tar=f.readline()[:-1]
        for line in f.readlines():
            seq = seq+line.strip('\n')
    f.close()
    
    wb=load_workbook('temp/'+str(loc)+'/extracted_temp.xlsx')
    ws=wb[wb.sheetnames[0]]
    rm=ws.max_row
    
    st=[]
    en=[]
    for r in range(2,rm+1):
        lo=ws.cell(r,1).value
        st.append(lo)
        en.append(lo+200)
    if(en==[] or st==[]):
        return 1
    else:
        if(en[-1]>8000):
            en[-1]=8000
        if(st[0]<1):
            st[0]=1
        
        f=open('temp/'+str(loc)+'/result.txt','w')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write('>'+str(fr*10000000+to)+'\n')
            f.write(sequence+'\n')
        f.close()
        
        f=open('temp/'+str(loc)+'/G_sequence_cluster.txt','a')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write(tar+'_'+str(fr*10000000+to)+'\n')
            f.write(sequence+'\n')
            f.write('\n')
        f.close()
        return 0

def extract_short_py(loc):
    seq=''
    with open('temp/'+str(loc)+'/Target.txt','r') as f:
        tar=f.readline()[:-1]
        for line in f.readlines():
            seq = seq+line.strip('\n')
    f.close()
    
    wb=load_workbook('temp/'+str(loc)+'/extracted_temp.xlsx')
    ws=wb[wb.sheetnames[0]]
    rm=ws.max_row
    
    st=[]
    en=[]
    for r in range(2,rm+1):
        lo=ws.cell(r,1).value
        st.append(lo)
        en.append(lo+200)
    if(en==[] or st==[]):
        return 1
    else:
        i=1
        mx=max(en)
        while(1):
            if(en[i-1]==mx):
                break
            if(st[i]<=en[i-1]):
                del st[i]
                del en[i-1]
                continue
            i=i+1
        
        if(en[-1]>8000):
            en[-1]=8000
        if(st[0]<1):
            st[0]=1
        
        f=open('temp/'+str(loc)+'/result.txt','w')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write('>'+str(fr*10000000+to)+'\n')
            f.write(sequence+'\n')
        f.close()
        
        f=open('temp/'+str(loc)+'/G_sequence_cluster.txt','a')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write(tar+'_'+str(fr*10000000+to)+'\n')
            f.write(sequence+'\n')
            f.write('\n')
        f.close()
        return 0