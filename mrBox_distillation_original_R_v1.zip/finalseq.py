# -*- coding: utf-8 -*-
"""
Created on Mon Mar 15 23:23:39 2021

@author: Yvan Guo
"""

from openpyxl import load_workbook

def finalseq_py(loc):
    seq=''
    with open('temp/'+str(loc)+'/Target.txt', 'r') as f:
        tar=f.readline()[:-1]
        for line in f.readlines():
            seq = seq+line.strip('\n')
    f.close()
    
    wb=load_workbook('temp/'+str(loc)+'/t_blast_temp.xlsx')
    ws=wb[wb.sheetnames[0]]
    rm=ws.max_row
    
    st=[]
    en=[]
    for r in range(2,rm+1):
        st.append(ws.cell(r,1).value)
        en.append(ws.cell(r,2).value)
    if(st==[] or en==[]):
        return 1
    else:
        f=open('cor_data_row/Significant_sequence_cluster_short.txt','a')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write(tar+'_'+str(fr)+'_'+str(to)+'\n')
            f.write(sequence+'\n')
            f.write('\n')
        f.close()
        
def finalseq_chr_py(loc,pth):
    seq=''
    with open('temp/'+str(loc)+'/Target.txt', 'r') as f:
        tar=f.readline()[:-1]
        for line in f.readlines():
            seq = seq+line.strip('\n')
    f.close()
    
    wb=load_workbook('temp/'+str(loc)+'/t_blast_temp.xlsx')
    ws=wb[wb.sheetnames[0]]
    rm=ws.max_row
    
    st=[]
    en=[]
    for r in range(2,rm+1):
        st.append(ws.cell(r,1).value)
        en.append(ws.cell(r,2).value)
    if(st==[] or en==[]):
        return 1
    else:
        f=open(pth+'/Significant_sequence_cluster.txt','a')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write(tar+'_'+str(fr)+'_'+str(to)+'\n')
            f.write(sequence+'\n')
            f.write('\n')
        f.close()

def finalseq_chr_short_py(loc,pth):
    seq=''
    with open('temp/'+str(loc)+'/Target.txt', 'r') as f:
        tar=f.readline()[:-1]
        for line in f.readlines():
            seq = seq+line.strip('\n')
    f.close()
    
    wb=load_workbook('temp/'+str(loc)+'/t_blast_temp.xlsx')
    ws=wb[wb.sheetnames[0]]
    rm=ws.max_row
    
    st=[]
    en=[]
    for r in range(2,rm+1):
        st.append(ws.cell(r,1).value)
        en.append(ws.cell(r,2).value)
    if(st==[] or en==[]):
        return 1
    else:
        f=open(pth+'/Significant_sequence_cluster_short.txt','a')
        l_st=len(st)
        for k in range(1,l_st+1):
            fr=st[k-1]
            to=en[k-1]+1
            sequence=seq[fr:to]
            f.write(tar+'_'+str(fr)+'_'+str(to)+'\n')
            f.write(sequence+'\n')
            f.write('\n')
        f.close()