# -*- coding: utf-8 -*-
"""
Created on Tue Jan 12 22:19:24 2021

@author: Yvan Guo
"""

def slice_py(loc):
    sequence=''
    with open('temp/'+str(loc)+'/Target.txt', 'r') as f:
        tar=f.readline()[:-1]
        for line in f.readlines():
            sequence = sequence+line.strip('\n')
    f.close()
    
    le=200
    step=100
    fr=1
    to=8000
    pre_seq=sequence
    pre_seq=pre_seq[fr:to]
    f=open('temp/'+str(loc)+'/Slice'+'_'+str(fr)+'_'+str(to)+'.txt','w')
    for r in range(1,len(pre_seq)-le+1,step):
        sequence=pre_seq[r:r+le]
        f.write('>'+str(r+fr-1)+'\n')
        f.write(sequence+'\n')    
    f.close()